print("Roses are red")
print("Violets are blue")
print("I'm sch")
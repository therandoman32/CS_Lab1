print("My name is Sebastian Beaulac")
print("My birth place is Charlottetown")
print("My age is 18")
print("My favourite icecream is maple walnut")